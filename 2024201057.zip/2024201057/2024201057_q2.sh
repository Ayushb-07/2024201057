awk -F',' '{print $3,$4}' access.log
