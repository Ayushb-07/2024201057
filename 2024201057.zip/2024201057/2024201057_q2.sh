#!/bin/bash

grep -o '[0-9]*$' power_levels.txt | awk '{s+=$1} END {print s}'
