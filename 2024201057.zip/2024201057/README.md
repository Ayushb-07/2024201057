[For Q.01 follow the given steps:]
1. Change execute-permissions with the command $ 'chmod +x 2024201057_q1.sh' 
2. Run the script.

[For Q.02 follow the given steps:]
1. Edit execute-permissions with the command $ 'chmod +x 2024201057_q2.sh' 
2. Run the script.