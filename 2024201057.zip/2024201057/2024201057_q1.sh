awk 'BEGIN {FS = ","} ; {sum+=$4} {print sum}' power_levels.txt
