#!/bin/bash

awk '$0 ~ /POST/ && $0 ~ /404/ { print }' access.log
